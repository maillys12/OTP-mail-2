/**
 * Mailly OTP - Google Apps Script backend
 */

const CONFIG = {
  SHEET_ID: 'ใส่_GOOGLE_SHEET_ID_ตรงนี้',
  SMSPOOL_KEY: 'ใส่_SMSPOOL_API_KEY_ตรงนี้',
  PROMPTPAY_ID: '0633390911',
  SLIP_FOLDER_ID: '',
  ADMIN_USERNAME: 'admin',

  SESSION_HOURS: 72,
  PASSWORD_HASH_ROUNDS: 1200,

  MIN_TOPUP: 50,
  DEFAULT_MARKUP: 2,
  DEFAULT_MIN_PRICE_THB: 7,
  CANCEL_UNLOCK_SECONDS: 180,

  SELLING_PRICE_RULES: [
    { maxUsd: 0.09, thb: 7 },
    { maxUsd: 0.29, thb: 10 },
    { maxUsd: 0.44, thb: 15 },
    { maxUsd: 0.60, thb: 20 },
    { maxUsd: 0.80, thb: 30 },
    { maxUsd: Infinity, thb: 45 }
  ],

  SMSPOOL: {
    base: 'https://api.smspool.net',
    services: '/request/services',
    countries: '/request/countries',
    successRate: '/request/success_rate',
    purchase: '/purchase/sms',
    check: '/sms/check',
    cancel: '/sms/cancel'
  }
};

const SCHEMAS = {
  Users: [
    'userId',
    'email',
    'balance',
    'createdAt',
    'status',
    'passwordHash',
    'passwordSalt',
    'passwordSetAt',
    'sessionHash',
    'sessionExpiresAt',
    'failedAttempts',
    'lockedUntil',
    'username',
    'credit',
    'updated_at',
    'active'
  ],

  Orders: [
    'orderId',
    'smspoolOrderId',
    'service',
    'country',
    'phone',
    'status',
    'price',
    'userId',
    'createdAt',
    'updatedAt',
    'service_id',
    'country_id',
    'cc',
    'phonenumber',
    'cost_usd',
    'sms',
    'cancel_unlock_at',
    'refunded_at'
  ],

  Transactions: [
    'transactionId',
    'userId',
    'amount',
    'type',
    'status',
    'reference',
    'createdAt'
  ],

  Settings: [
    'key',
    'value',
    'updatedAt'
  ],

  Logs: [
    'time',
    'action',
    'requestId',
    'error',
    'details'
  ],

  Topups: [
    'topup_id',
    'username',
    'amount',
    'status',
    'slip_url',
    'created_at',
    'reviewed_at',
    'note',
    'slip_hash'
  ],

  Products: [
    'product_id',
    'name',
    'description',
    'category',
    'price',
    'icon',
    'logo_url',
    'active'
  ],

  ProductStock: [
    'stock_id',
    'product_id',
    'item_data',
    'sold',
    'created_at',
    'sold_at'
  ],

  Purchases: [
    'purchase_id',
    'username',
    'product_id',
    'product_name',
    'price',
    'item_data',
    'created_at'
  ],

  YTData: [
    'username',
    'family_id',
    'email',
    'status',
    'expire_date',
    'slip_url',
    'updated_at'
  ],

  Inbox: [
    'message_id',
    'username',
    'message',
    'created_at'
  ]
};

function doGet() {
  return json_({
    success: true,
    service: 'Mailly OTP backend',
    time: new Date().toISOString()
  });
}

function doPost(e) {
  const requestId = newId_('REQ');
  let action = 'unknown';

  try {
    const body = JSON.parse(
      (e && e.postData && e.postData.contents) || '{}'
    );

    action = String(body.action || '');
    const p = body.payload || {};

    if (!action) {
      return json_({
        success: false,
        message: 'ไม่พบ action'
      });
    }

    const result = dispatch_(action, p);

    log_(action, requestId, '', {
      success: true
    });

    return json_(
      Object.assign(
        {
          requestId: requestId
        },
        result
      )
    );

  } catch (err) {
    const message = safeError_(err);

    console.error(err.stack || err);

    log_(action, requestId, message, {});

    return json_({
      success: false,
      requestId: requestId,
      message: message
    });
  }
}

function dispatch_(action, p) {
  switch (action) {
    case 'loginUser':
      return withScriptLock_(function() {
        return loginUser_(p);
      });

    case 'registerUser':
      return withScriptLock_(function() {
        return registerUser_(p);
      });

    case 'getSessionUser':
      return getSessionUser_(p);

    case 'logoutUser':
      return logoutUser_(p);

    case 'getMyOrders':
      return getMyOrders_(p);

    case 'getPriceQuote':
      return getPriceQuote_(p);

    case 'getServices':
      return getServices_();

    case 'getCountryDataForService':
      return getCountries_(p);

    case 'buyNumberWithCredit':
      return withScriptLock_(function() {
        return buyNumber_(p);
      });

    case 'buyKeepNumberWithCredit':
      return buyKeepNumber_(p);

    case 'checkOTP':
      return withScriptLock_(function() {
        return checkOtp_(p);
      });

    case 'cancelOrderWithRefund':
      return withScriptLock_(function() {
        return cancelOrder_(p);
      });

    case 'resendSMSWithCredit':
      return resendSms_(p);

    case 'topupUserCredit':
      return withScriptLock_(function() {
        return createTopup_(p);
      });

    case 'buyProductWithCredit':
      return withScriptLock_(function() {
        return buyProduct_(p);
      });

    case 'getShopProducts':
      return getShopProducts_(p);

    case 'getMyPurchases':
      return getMyPurchases_(p);

    case 'buyYtPackageWithCredit':
      return withScriptLock_(function() {
        return buyYtPackage_(p);
      });

    case 'getYtUserData':
      return getYtUserData_(p);

    case 'getAllYtDataForAdmin':
      return getAllYtDataForAdmin_(p);

    case 'updateYtUserDataFromAdmin':
      return updateYtUserDataFromAdmin_(p);

    case 'processYtPayment':
      return processYtPayment_(p);

    case 'getUserInboxMessages':
      return getInbox_(p);

    case 'sendUserInboxMessage':
      return sendInbox_(p);

    case 'requestBackupEmail':
      return requestBackupEmail_(p);

    case 'getSettings':
      return getSettings_(p);

    case 'setSetting':
      return setSetting_(p);

    default:
      return {
        success: false,
        message: 'ไม่รองรับ action: ' + action
      };
  }
}

/* =====================================================
   SETUP GOOGLE SHEETS
===================================================== */

function setupSheets() {
  const ss = spreadsheet_();

  Object.keys(SCHEMAS).forEach(function(name) {
    let sh = ss.getSheetByName(name);

    if (!sh) {
      sh = ss.insertSheet(name);
    }

    const headers = SCHEMAS[name];

    if (sh.getLastRow() === 0) {
      sh
        .getRange(1, 1, 1, headers.length)
        .setValues([headers]);
    } else {
      ensureSchemaHeaders_(sh, headers);
    }

    sh.setFrozenRows(1);
  });

  migrateLegacyUserSheet_();
  seedSettings_();

  return 'สร้าง/ตรวจสอบชีตเรียบร้อยแล้ว';
}

function ensureSchemaHeaders_(sh, requiredHeaders) {
  const current = headerRow_(sh);

  const missing = requiredHeaders.filter(function(h) {
    return current.indexOf(h) < 0;
  });

  if (missing.length) {
    sh
      .getRange(
        1,
        current.length + 1,
        1,
        missing.length
      )
      .setValues([missing]);
  }
}

function migrateLegacyUserSheet_() {
  const ss = spreadsheet_();
  const legacy = ss.getSheetByName('User');
  const target = ss.getSheetByName('Users');

  if (
    !legacy ||
    !target ||
    target.getLastRow() > 1 ||
    legacy.getLastRow() < 2
  ) {
    return;
  }

  const values = legacy.getDataRange().getValues();
  const headers = values[0].map(String);

  const idx = function(names) {
    return names
      .map(function(n) {
        return headers.indexOf(n);
      })
      .find(function(i) {
        return i >= 0;
      });
  };

  for (let r = 1; r < values.length; r++) {
    const userIndex = idx([
      'userId',
      'username',
      'user_id'
    ]);

    const userId =
      userIndex >= 0
        ? values[r][userIndex]
        : values[r][0];

    if (!userId) continue;

    const emailIndex = idx(['email']);
    const balanceIndex = idx([
      'balance',
      'credit'
    ]);

    const balance =
      balanceIndex >= 0
        ? values[r][balanceIndex]
        : 0;

    append_('Users', {
      userId: userId,
      username: userId,
      email:
        emailIndex >= 0
          ? values[r][emailIndex]
          : '',
      balance: balance,
      credit: balance,
      createdAt: now_(),
      status: 'active'
    });
  }
}

/* =====================================================
   DATABASE HELPERS
===================================================== */

function spreadsheet_() {
  if (
    !CONFIG.SHEET_ID ||
    CONFIG.SHEET_ID.indexOf('ใส่_') === 0
  ) {
    throw new Error(
      'กรุณาใส่ SHEET_ID ใน CONFIG'
    );
  }

  return SpreadsheetApp.openById(
    CONFIG.SHEET_ID
  );
}

function sheet_(name) {
  const sh = spreadsheet_().getSheetByName(name);

  if (!sh) {
    throw new Error(
      'ไม่พบชีต ' +
      name +
      ' กรุณารัน setupSheets()'
    );
  }

  return sh;
}

function rows_(name) {
  const sh = sheet_(name);
  const values = sh.getDataRange().getValues();

  if (values.length < 2) {
    return [];
  }

  const headers = values[0].map(String);

  return values.slice(1).map(function(row, i) {
    const obj = {
      _row: i + 2
    };

    headers.forEach(function(h, j) {
      obj[h] = row[j];
    });

    alias_(obj, 'userId', [
      'username',
      'user_id'
    ]);

    alias_(obj, 'username', [
      'userId',
      'user_id'
    ]);

    alias_(obj, 'balance', ['credit']);
    alias_(obj, 'credit', ['balance']);

    alias_(obj, 'createdAt', [
      'created_at'
    ]);

    alias_(obj, 'created_at', [
      'createdAt'
    ]);

    alias_(obj, 'orderId', ['order_id']);
    alias_(obj, 'order_id', ['orderId']);

    alias_(obj, 'smspoolOrderId', [
      'provider_order_id'
    ]);

    alias_(obj, 'provider_order_id', [
      'smspoolOrderId'
    ]);

    alias_(obj, 'service', [
      'service_name'
    ]);

    alias_(obj, 'service_name', [
      'service'
    ]);

    alias_(obj, 'country', [
      'country_name'
    ]);

    alias_(obj, 'country_name', [
      'country'
    ]);

    alias_(obj, 'phone', [
      'phonenumber'
    ]);

    alias_(obj, 'phonenumber', [
      'phone'
    ]);

    alias_(obj, 'price', [
      'price_thb'
    ]);

    alias_(obj, 'price_thb', [
      'price'
    ]);

    return obj;
  });
}

function alias_(obj, primary, alternatives) {
  if (
    obj[primary] !== undefined &&
    obj[primary] !== ''
  ) {
    return;
  }

  for (
    let i = 0;
    i < alternatives.length;
    i++
  ) {
    if (
      obj[alternatives[i]] !== undefined &&
      obj[alternatives[i]] !== ''
    ) {
      obj[primary] = obj[alternatives[i]];
      return;
    }
  }
}

function append_(name, obj) {
  const sh = sheet_(name);
  const headers = headerRow_(sh);

  sh.appendRow(
    headers.map(function(h) {
      return valueForHeader_(obj, h);
    })
  );
}

function updateRow_(name, rowNumber, obj) {
  const sh = sheet_(name);
  const headers = headerRow_(sh);

  const current = sh
    .getRange(
      rowNumber,
      1,
      1,
      headers.length
    )
    .getValues()[0];

  const next = headers.map(function(h, i) {
    return hasValueForHeader_(obj, h)
      ? valueForHeader_(obj, h)
      : current[i];
  });

  sh
    .getRange(
      rowNumber,
      1,
      1,
      headers.length
    )
    .setValues([next]);
}

function headerRow_(sh) {
  return sh
    .getRange(
      1,
      1,
      1,
      sh.getLastColumn()
    )
    .getValues()[0]
    .map(String);
}

function headerAliases_(header) {
  const map = {
    userId: [
      'userId',
      'username',
      'user_id'
    ],

    email: ['email'],

    balance: [
      'balance',
      'credit'
    ],

    credit: [
      'credit',
      'balance'
    ],

    createdAt: [
      'createdAt',
      'created_at'
    ],

    created_at: [
      'created_at',
      'createdAt'
    ],

    updatedAt: [
      'updatedAt',
      'updated_at'
    ],

    updated_at: [
      'updated_at',
      'updatedAt'
    ],

    orderId: [
      'orderId',
      'order_id'
    ],

    order_id: [
      'order_id',
      'orderId'
    ],

    smspoolOrderId: [
      'smspoolOrderId',
      'provider_order_id'
    ],

    provider_order_id: [
      'provider_order_id',
      'smspoolOrderId'
    ],

    service: [
      'service',
      'service_name'
    ],

    service_name: [
      'service_name',
      'service'
    ],

    country: [
      'country',
      'country_name'
    ],

    country_name: [
      'country_name',
      'country'
    ],

    phone: [
      'phone',
      'phonenumber'
    ],

    phonenumber: [
      'phonenumber',
      'phone'
    ],

    price: [
      'price',
      'price_thb'
    ],

    price_thb: [
      'price_thb',
      'price'
    ],

    time: [
      'time',
      'timestamp'
    ],

    requestId: [
      'requestId',
      'request_id'
    ],

    error: ['error'],
    details: ['details']
  };

  return map[header] || [header];
}

function hasValueForHeader_(obj, header) {
  return headerAliases_(header).some(
    function(k) {
      return obj[k] !== undefined;
    }
  );
}

function valueForHeader_(obj, header) {
  const aliases = headerAliases_(header);

  for (
    let i = 0;
    i < aliases.length;
    i++
  ) {
    if (obj[aliases[i]] !== undefined) {
      return obj[aliases[i]];
    }
  }

  return '';
}

function now_() {
  return Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone() ||
      'Asia/Bangkok',
    'yyyy-MM-dd HH:mm:ss'
  );
}

function money_(n) {
  return (
    Math.round(
      (Number(n) || 0) * 100
    ) / 100
  );
}

function withScriptLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

function key_(s) {
  return String(s || '')
    .trim()
    .toLowerCase();
}

function json_(obj) {
  return ContentService
    .createTextOutput(
      JSON.stringify(obj)
    )
    .setMimeType(
      ContentService.MimeType.JSON
    );
}

function safeError_(e) {
  return String(
    (e && e.message) || e
  ).replace(
    /https?:\/\/[^\s]+/g,
    '[url]'
  );
}

function newId_(prefix) {
  return (
    prefix +
    '-' +
    Utilities.getUuid()
      .replace(/-/g, '')
      .slice(0, 18)
      .toUpperCase()
  );
}

/* =====================================================
   SETTINGS / LOGS / TRANSACTIONS
===================================================== */

function seedSettings_() {
  const sh = sheet_('Settings');

  if (sh.getLastRow() > 1) {
    return;
  }

  [
    [
      'markup',
      CONFIG.DEFAULT_MARKUP
    ],
    [
      'min_price_thb',
      CONFIG.DEFAULT_MIN_PRICE_THB
    ],
    [
      'service_enabled',
      'true'
    ],
    [
      'maintenance',
      'false'
    ]
  ].forEach(function(x) {
    append_('Settings', {
      key: x[0],
      value: x[1],
      updatedAt: now_()
    });
  });
}

function setting_(key, fallback) {
  const r = rows_('Settings').find(
    function(x) {
      return (
        String(x.key) === String(key)
      );
    }
  );

  return r && r.value !== ''
    ? r.value
    : fallback;
}

function log_(
  action,
  requestId,
  error,
  details
) {
  try {
    append_('Logs', {
      time: now_(),
      action: action,
      requestId: requestId,
      error: error || '',
      details: JSON.stringify(
        details || {}
      )
    });
  } catch (e) {
    console.error(e);
  }
}

function transaction_(
  userId,
  amount,
  type,
  status,
  reference
) {
  append_('Transactions', {
    transactionId: newId_('TXN'),
    userId: userId,
    amount: money_(amount),
    type: type,
    status: status,
    reference: reference || '',
    createdAt: now_()
  });
}

function getSettings_(p) {
  requireAdmin_(p);
  return rows_('Settings').map(
    function(r) {
      return {
        key: r.key,
        value: r.value,
        updatedAt:
          r.updatedAt ||
          r.updated_at
      };
    }
  );
}

function setSetting_(p) {
  requireAdmin_(p);

  const row = rows_('Settings').find(
    function(r) {
      return (
        String(r.key) ===
        String(p.key)
      );
    }
  );

  if (row) {
    updateRow_(
      'Settings',
      row._row,
      {
        value: p.value,
        updatedAt: now_()
      }
    );
  } else {
    append_('Settings', {
      key: p.key,
      value: p.value,
      updatedAt: now_()
    });
  }

  return {
    success: true
  };
}

/* =====================================================
   USER / CREDIT
===================================================== */

function user_(username, create) {
  username = String(
    username || ''
  ).trim();

  if (
    !/^[\wก-๙. -]{2,50}$/u.test(
      username
    )
  ) {
    throw new Error(
      'ชื่อผู้ใช้ไม่ถูกต้อง'
    );
  }

  const k = key_(username);
  const list = rows_('Users');

  let found = list.find(function(r) {
    return (
      key_(
        r.userId || r.username
      ) === k
    );
  });

  if (!found && create) {
    append_('Users', {
      userId: username,
      username: username,
      email: '',
      balance: 0,
      credit: 0,
      createdAt: now_(),
      created_at: now_(),
      status: 'active',
      updated_at: now_(),
      active: true
    });

    found = rows_('Users').find(
      function(r) {
        return (
          key_(
            r.userId ||
            r.username
          ) === k
        );
      }
    );
  }

  if (!found) {
    throw new Error(
      'ไม่พบผู้ใช้งานหรือบัญชีถูกระงับ'
    );
  }

  const activeValue = String(found.active).trim().toLowerCase();
  const statusValue = String(found.status).trim().toLowerCase();
  if (
    activeValue === 'false' ||
    statusValue === 'suspended' ||
    statusValue === 'inactive'
  ) {
    throw new Error('ไม่พบผู้ใช้งานหรือบัญชีถูกระงับ');
  }

  found.username =
    found.userId ||
    found.username;

  found.credit =
    Number(
      found.balance !== undefined &&
      found.balance !== ''
        ? found.balance
        : found.credit
    ) || 0;

  return found;
}

function changeCredit_(
  username,
  delta
) {
  const u = user_(
    username,
    true
  );

  const next = money_(
    Number(u.credit) +
    Number(delta)
  );

  if (next < -0.0001) {
    throw new Error(
      'เครดิตไม่เพียงพอ'
    );
  }

  updateRow_(
    'Users',
    u._row,
    {
      balance: next,
      credit: next,
      updated_at: now_(),
      updatedAt: now_()
    }
  );

  transaction_(
    u.username,
    delta,
    Number(delta) >= 0
      ? 'credit'
      : 'debit',
    'completed',
    'balance'
  );

  return next;
}

/* =====================================================
   LOGIN / REGISTER / SESSION
===================================================== */

function loginUser_(p) {
  const username = String(
    p.username || ''
  ).trim();

  const password = String(
    p.password || ''
  );

  if (!username || !password) {
    throw new Error(
      'กรุณากรอก Username และ Password'
    );
  }

  const u = user_(
    username,
    false
  );

  if (
    !u.passwordHash ||
    !u.passwordSalt
  ) {
    return {
      success: false,
      needsPasswordSetup: true,
      message:
        'บัญชีเดิมนี้ยังไม่มีรหัสผ่าน กรุณาเลือกสมัครสมาชิกเพื่อตั้งรหัสผ่านครั้งแรก'
    };
  }

  const lockedUntil =
    new Date(
      u.lockedUntil || 0
    ).getTime();

  if (
    lockedUntil > Date.now()
  ) {
    throw new Error(
      'บัญชีถูกล็อกชั่วคราว กรุณารอ 15 นาทีแล้วลองใหม่'
    );
  }

  const attemptedHash =
    passwordHash_(
      password,
      u.passwordSalt
    );

  if (
    !constantTimeEqual_(
      attemptedHash,
      String(u.passwordHash)
    )
  ) {
    const failed =
      Number(
        u.failedAttempts || 0
      ) + 1;

    updateRow_(
      'Users',
      u._row,
      {
        failedAttempts:
          failed >= 5
            ? 0
            : failed,

        lockedUntil:
          failed >= 5
            ? new Date(
                Date.now() +
                15 * 60 * 1000
              )
            : ''
      }
    );

    throw new Error(
      failed >= 5
        ? 'รหัสผ่านไม่ถูกต้อง บัญชีถูกล็อก 15 นาที'
        : 'Username หรือ Password ไม่ถูกต้อง'
    );
  }

  updateRow_(
    'Users',
    u._row,
    {
      failedAttempts: 0,
      lockedUntil: ''
    }
  );

  return createSessionResponse_(u);
}

function registerUser_(p) {
  const username = String(
    p.username || ''
  ).trim();

  const email = String(
    p.email || ''
  )
    .trim()
    .toLowerCase();

  const password = String(
    p.password || ''
  );

  const confirmPassword = String(
    p.confirmPassword || ''
  );

  if (
    !/^[A-Za-z0-9_.-]{3,24}$/.test(
      username
    )
  ) {
    throw new Error(
      'Username ต้องมี 3–24 ตัว และใช้ได้เฉพาะ a-z, 0-9, จุด ขีดกลาง หรือขีดล่าง'
    );
  }

  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      email
    )
  ) {
    throw new Error(
      'รูปแบบ Email ไม่ถูกต้อง'
    );
  }

  validatePassword_(password);

  if (
    password !== confirmPassword
  ) {
    throw new Error(
      'ยืนยัน Password ไม่ตรงกัน'
    );
  }

  const users = rows_('Users');

  let u = users.find(function(r) {
    return (
      key_(
        r.userId ||
        r.username
      ) === key_(username)
    );
  });

  const emailOwner = users.find(
    function(r) {
      return (
        key_(r.email) ===
          key_(email) &&
        key_(
          r.userId ||
          r.username
        ) !== key_(username)
      );
    }
  );

  if (emailOwner) {
    throw new Error(
      'Email นี้ถูกใช้กับบัญชีอื่นแล้ว'
    );
  }

  if (
    u &&
    u.passwordHash
  ) {
    throw new Error(
      'Username นี้สมัครสมาชิกแล้ว กรุณาเข้าสู่ระบบ'
    );
  }

  if (
    u &&
    !u.email
  ) {
    throw new Error(
      'บัญชีเดิมนี้ยังไม่มี Email กรุณาให้แอดมินเพิ่ม Email ในชีต Users ก่อนตั้ง Password ครั้งแรก'
    );
  }

  if (
    u &&
    u.email &&
    key_(u.email) !== key_(email)
  ) {
    throw new Error(
      'Email ไม่ตรงกับข้อมูลสมาชิกเดิม กรุณาติดต่อแอดมิน'
    );
  }

  const salt = randomToken_();

  const hash = passwordHash_(
    password,
    salt
  );

  if (u) {
    updateRow_(
      'Users',
      u._row,
      {
        email: email,
        passwordHash: hash,
        passwordSalt: salt,
        passwordSetAt: now_(),
        status: 'active',
        active: true,
        updated_at: now_()
      }
    );
  } else {
    append_('Users', {
      userId: username,
      username: username,
      email: email,
      balance: 0,
      credit: 0,
      createdAt: now_(),
      status: 'active',
      active: true,
      passwordHash: hash,
      passwordSalt: salt,
      passwordSetAt: now_(),
      failedAttempts: 0
    });
  }

  u = user_(
    username,
    false
  );

  transaction_(
    username,
    0,
    'register',
    'completed',
    'member-registration'
  );

  return createSessionResponse_(u);
}

function createSessionResponse_(u) {
  const token =
    randomToken_() +
    randomToken_();

  const expires =
    new Date(
      Date.now() +
      CONFIG.SESSION_HOURS *
      60 *
      60 *
      1000
    );

  updateRow_(
    'Users',
    u._row,
    {
      sessionHash:
        sha256_(token),

      sessionExpiresAt:
        expires,

      updated_at: now_()
    }
  );

  return {
    success: true,
    token: token,
    expiresAt:
      expires.toISOString(),
    user: publicUser_(u)
  };
}

function getSessionUser_(p) {
  return {
    success: true,
    user: publicUser_(
      requireAuth_(p)
    )
  };
}

function logoutUser_(p) {
  const u = requireAuth_(p);

  updateRow_(
    'Users',
    u._row,
    {
      sessionHash: '',
      sessionExpiresAt: ''
    }
  );

  return {
    success: true
  };
}

function requireAuth_(p) {
  const token = String(
    (p && p.token) || ''
  );

  if (!token) {
    throw new Error(
      'กรุณาเข้าสู่ระบบใหม่'
    );
  }

  const tokenHash =
    sha256_(token);

  const raw = rows_('Users').find(
    function(r) {
      return (
        r.sessionHash &&
        constantTimeEqual_(
          String(r.sessionHash),
          tokenHash
        )
      );
    }
  );

  if (
    !raw ||
    new Date(
      raw.sessionExpiresAt || 0
    ).getTime() <= Date.now()
  ) {
    throw new Error(
      'Session หมดอายุ กรุณาเข้าสู่ระบบใหม่'
    );
  }

  return user_(
    raw.userId ||
    raw.username,
    false
  );
}

function requireAdmin_(p) {
  const u = requireAuth_(p);
  if (key_(u.username) !== key_(CONFIG.ADMIN_USERNAME)) {
    throw new Error('ไม่มีสิทธิ์ใช้งานส่วนแอดมิน');
  }
  return u;
}

function publicUser_(u) {
  const balance = money_(
    u.balance !== undefined &&
    u.balance !== ''
      ? u.balance
      : u.credit
  );

  return {
    userId:
      u.userId ||
      u.username,

    username:
      u.userId ||
      u.username,

    email:
      u.email || '',

    balance: balance,
    credit: balance
  };
}

function validatePassword_(password) {
  if (
    password.length < 8 ||
    password.length > 72
  ) {
    throw new Error(
      'Password ต้องมี 8–72 ตัวอักษร'
    );
  }

  if (
    !/[A-Za-z]/.test(password) ||
    !/[0-9]/.test(password)
  ) {
    throw new Error(
      'Password ต้องมีทั้งตัวอักษรและตัวเลข'
    );
  }
}

function randomToken_() {
  return (
    Utilities.getUuid()
      .replace(/-/g, '') +
    Utilities.getUuid()
      .replace(/-/g, '')
  );
}

function passwordHash_(
  password,
  salt
) {
  let value =
    String(salt) +
    '|' +
    String(password) +
    '|' +
    authPepper_();

  for (
    let i = 0;
    i <
    CONFIG.PASSWORD_HASH_ROUNDS;
    i++
  ) {
    value = sha256_(
      value + '|' + i
    );
  }

  return value;
}

function authPepper_() {
  const props =
    PropertiesService
      .getScriptProperties();

  let pepper =
    props.getProperty(
      'AUTH_PEPPER'
    );

  if (!pepper) {
    pepper = randomToken_();

    props.setProperty(
      'AUTH_PEPPER',
      pepper
    );
  }

  return pepper;
}

function sha256_(value) {
  const bytes =
    Utilities.computeDigest(
      Utilities.DigestAlgorithm
        .SHA_256,
      String(value),
      Utilities.Charset.UTF_8
    );

  return bytes
    .map(function(b) {
      const v =
        b < 0
          ? b + 256
          : b;

      return (
        '0' +
        v.toString(16)
      ).slice(-2);
    })
    .join('');
}

function constantTimeEqual_(a, b) {
  a = String(a);
  b = String(b);

  let diff =
    a.length ^ b.length;

  const length =
    Math.max(
      a.length,
      b.length
    );

  for (
    let i = 0;
    i < length;
    i++
  ) {
    diff |=
      (
        a.charCodeAt(
          i % (a.length || 1)
        ) || 0
      ) ^
      (
        b.charCodeAt(
          i % (b.length || 1)
        ) || 0
      );
  }

  return diff === 0;
}

/* =====================================================
   SMSPOOL
===================================================== */

function orderView_(o) {
  return {
    order_id:
      o.orderId ||
      o.order_id,

    fullNumber:
      '+' +
      (o.cc || '') +
      ' ' +
      (
        o.phonenumber ||
        o.phone ||
        ''
      ),

    price: money_(
      o.price !== undefined
        ? o.price
        : o.price_thb
    ),

    time:
      o.createdAt ||
      o.created_at,

    status: o.status
  };
}

function smspool_(
  path,
  params,
  method
) {
  if (
    !CONFIG.SMSPOOL_KEY ||
    CONFIG.SMSPOOL_KEY.indexOf(
      'ใส่_'
    ) === 0
  ) {
    throw new Error(
      'กรุณาใส่ SMSPOOL_KEY ใน CONFIG'
    );
  }

  params = params || {};
  params.key =
    CONFIG.SMSPOOL_KEY;

  const options = {
    method:
      method || 'post',
    payload: params,
    muteHttpExceptions: true
  };

  const response =
    UrlFetchApp.fetch(
      CONFIG.SMSPOOL.base + path,
      options
    );

  const code =
    response.getResponseCode();

  const text =
    response.getContentText();

  if (code >= 400) {
    throw new Error(
      'SMSPool HTTP ' + code
    );
  }

  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error(
      'SMSPool ส่งข้อมูลไม่ใช่ JSON'
    );
  }
}

function getServices_() {
  if (
    String(
      setting_(
        'service_enabled',
        'true'
      )
    ).toLowerCase() !== 'true'
  ) {
    throw new Error(
      'ระบบบริการ OTP ปิดชั่วคราว'
    );
  }

  const data = smspool_(
    CONFIG.SMSPOOL.services,
    {}
  );

  return Array.isArray(data)
    ? data
    : (
        data.services ||
        data.data ||
        data
      );
}

function getCountries_(p) {
  const serviceId =
    p.serviceId;

  if (!serviceId) {
    throw new Error(
      'ไม่พบ serviceId'
    );
  }

  let data = smspool_(
    CONFIG.SMSPOOL.successRate,
    {
      service: serviceId
    }
  );

  if (
    Array.isArray(data) ||
    typeof data === 'object'
  ) {
    const list =
      Array.isArray(data)
        ? data
        : (
            data.data ||
            data.countries ||
            data
          );

    if (
      Array.isArray(list) &&
      list.length
    ) {
      return list;
    }
  }

  data = smspool_(
    CONFIG.SMSPOOL.countries,
    {}
  );

  return Array.isArray(data)
    ? data
    : (
        data.countries ||
        data.data ||
        data
      );
}

function priceFromUsd_(usd) {
  const n = Number(usd);

  for (
    let i = 0;
    i <
    CONFIG
      .SELLING_PRICE_RULES
      .length;
    i++
  ) {
    if (!isNaN(n) && n >= 0 &&
      n <=
      CONFIG
        .SELLING_PRICE_RULES[i]
        .maxUsd
    ) {
      return CONFIG
        .SELLING_PRICE_RULES[i]
        .thb;
    }
  }

  return 45;
}

function getPriceQuote_(p) {
  requireAuth_(p);

  const countries =
    getCountries_({
      serviceId: p.serviceId
    });

  const info =
    (
      Array.isArray(countries)
        ? countries
        : []
    ).find(function(c) {
      return (
        String(
          c.country_id ||
          c.id
        ) ===
        String(p.countryId)
      );
    });

  if (
    !info ||
    info.price === undefined
  ) {
    throw new Error(
      'ไม่พบราคาสำหรับประเทศนี้'
    );
  }

  return {
    success: true,
    price:
      priceFromUsd_(
        info.price
      ),

    providerPriceUsd:
      Number(info.price) || 0
  };
}

function getMyOrders_(p) {
  const u = requireAuth_(p);

  const items = rows_('Orders')
    .filter(function(o) {
      return (
        key_(
          o.userId ||
          o.username
        ) ===
        key_(u.username)
      );
    })
    .slice(-30)
    .reverse()
    .map(function(o) {
      return {
        orderId:
          o.orderId ||
          o.order_id,

        service:
          o.service ||
          o.service_name ||
          '',

        country:
          o.country ||
          o.country_name ||
          '',

        phone:
          (
            o.cc
              ? '+' + o.cc
              : ''
          ) +
          String(
            o.phonenumber ||
            o.phone ||
            ''
          ),

        status:
          o.status || '',

        price:
          money_(
            o.price !== undefined
              ? o.price
              : o.price_thb
          ),

        sms:
          o.sms || '',

        createdAt:
          o.createdAt ||
          o.created_at ||
          ''
      };
    });

  return {
    success: true,
    orders: items
  };
}

function buyNumber_(p) {
  const u = requireAuth_(p);

  const service = String(
    p.serviceId || ''
  );

  const country = String(
    p.countryId || ''
  );

  if (
    !service ||
    !country
  ) {
    throw new Error(
      'กรุณาเลือกบริการและประเทศ'
    );
  }

  const countries =
    getCountries_({
      serviceId: service
    });

  const info =
    (
      Array.isArray(countries)
        ? countries
        : []
    ).find(function(c) {
      return (
        String(
          c.country_id ||
          c.id
        ) === country
      );
    });

  if (
    !info ||
    info.price === undefined
  ) {
    throw new Error(
      'ไม่พบราคาหรือประเทศที่เลือก'
    );
  }

  const sellPrice =
    priceFromUsd_(
      info.price
    );

  if (
    money_(u.credit) <
    sellPrice
  ) {
    throw new Error(
      'เครดิตไม่เพียงพอ ต้องใช้ ' +
      sellPrice +
      ' บาท'
    );
  }

  const provider = smspool_(
    CONFIG.SMSPOOL.purchase,
    {
      country: country,
      service: service
    }
  );

  if (
    !provider ||
    Number(
      provider.success
    ) !== 1
  ) {
    throw new Error(
      (
        provider &&
        (
          provider.message ||
          provider.type
        )
      ) ||
      'SMSPool ไม่มีเบอร์ว่าง'
    );
  }

  const orderId =
    newId_('OTP');

  const newCredit =
    changeCredit_(
      u.username,
      -sellPrice
    );

  append_('Orders', {
    orderId: orderId,
    order_id: orderId,

    userId: u.username,
    username: u.username,

    smspoolOrderId:
      provider.order_id,

    provider_order_id:
      provider.order_id,

    service:
      provider.service ||
      info.name ||
      service,

    service_id: service,

    country:
      provider.country ||
      info.name ||
      country,

    country_id: country,

    phone:
      provider.phonenumber,

    phonenumber:
      provider.phonenumber,

    cc: provider.cc,

    price: sellPrice,
    price_thb: sellPrice,

    cost_usd:
      provider.cost,

    status: 'pending',
    sms: '',

    createdAt: now_(),
    created_at: now_(),
    updatedAt: now_(),

    cancel_unlock_at:
      new Date(
        Date.now() +
        CONFIG
          .CANCEL_UNLOCK_SECONDS *
        1000
      ),

    refunded_at: ''
  });

  return {
    success: true,
    order_id: orderId,
    cc: provider.cc,
    phonenumber:
      provider.phonenumber,
    newCredit: newCredit
  };
}

function orderForUser_(
  username,
  orderId
) {
  user_(username, false);

  const o = rows_('Orders').find(
    function(r) {
      return (
        String(
          r.orderId ||
          r.order_id
        ) ===
          String(orderId) &&
        key_(
          r.userId ||
          r.username
        ) ===
          key_(username)
      );
    }
  );

  if (!o) {
    throw new Error(
      'ไม่พบคำสั่งซื้อ'
    );
  }

  return o;
}

function checkOtp_(p) {
  const u = requireAuth_(p);

  const o = rows_('Orders').find(
    function(r) {
      return (
        String(
          r.orderId ||
          r.order_id
        ) ===
          String(p.orderId) &&
        key_(
          r.userId ||
          r.username
        ) ===
          key_(u.username)
      );
    }
  );

  if (!o) {
    throw new Error(
      'ไม่พบคำสั่งซื้อ'
    );
  }

  const result = smspool_(
    CONFIG.SMSPOOL.check,
    {
      orderid:
        o.smspoolOrderId ||
        o.provider_order_id
    }
  );

  const status =
    Number(result.status);

  if (
    status === 3 &&
    result.sms
  ) {
    updateRow_(
      'Orders',
      o._row,
      {
        status: 'completed',
        sms: result.sms
      }
    );
  } else if (status === 6) {
    if (!o.refunded_at && String(o.status) !== 'refunded') {
      changeCredit_(
        o.userId || o.username,
        Number(o.price !== undefined ? o.price : o.price_thb)
      );
    }
    updateRow_(
      'Orders',
      o._row,
      {
        status: 'refunded',
        refunded_at: o.refunded_at || now_(),
        updatedAt: now_()
      }
    );
  } else if (status === 2) {
    updateRow_(
      'Orders',
      o._row,
      {
        status: 'expired',
        updatedAt: now_()
      }
    );
  }

  return result;
}

function cancelOrder_(p) {
  const u = requireAuth_(p);

  const o = orderForUser_(
    u.username,
    p.orderId
  );

  if (
    [
      'completed',
      'refunded',
      'cancelled',
      'expired'
    ].indexOf(
      String(o.status)
    ) >= 0
  ) {
    throw new Error(
      'คำสั่งซื้อนี้ปิดไปแล้ว'
    );
  }

  if (
    new Date(
      o.cancel_unlock_at
    ).getTime() > Date.now()
  ) {
    throw new Error(
      'ยังยกเลิกไม่ได้ กรุณารอให้ครบ 3 นาที'
    );
  }

  const provider = smspool_(
    CONFIG.SMSPOOL.cancel,
    {
      orderid:
        o.smspoolOrderId ||
        o.provider_order_id
    }
  );

  if (
    Number(
      provider.success
    ) !== 1
  ) {
    throw new Error(
      provider.message ||
      'SMSPool ปฏิเสธการยกเลิก'
    );
  }

  const newCredit =
    changeCredit_(
      o.userId ||
      o.username,

      Number(
        o.price !== undefined
          ? o.price
          : o.price_thb
      )
    );

  updateRow_(
    'Orders',
    o._row,
    {
      status: 'refunded',
      refunded_at: now_(),
      updatedAt: now_()
    }
  );

  return {
    success: true,
    newCredit: newCredit
  };
}

function resendSms_(p) {
  requireAuth_(p);
  throw new Error(
    'ปิดฟังก์ชันขอ OTP ซ้ำชั่วคราวจนกว่าจะตั้งค่า endpoint resend ของ SMSPool'
  );
}

function buyKeepNumber_(p) {
  throw new Error(
    'ฟังก์ชันเช่าเบอร์ระยะยาวยังต้องระบุ endpoint rental ของ SMSPool ก่อน'
  );
}

/* =====================================================
   TOPUP
===================================================== */

function createTopup_(p) {
  const amount =
    money_(p.amount);

  if (
    amount <
    CONFIG.MIN_TOPUP
  ) {
    throw new Error(
      'เติมขั้นต่ำ ' +
      CONFIG.MIN_TOPUP +
      ' บาท'
    );
  }

  const u = requireAuth_(p);
  const image = p.imageObj || {};

  if (!image.base64) {
    throw new Error(
      'ไม่พบไฟล์สลิป'
    );
  }

  if (String(image.base64).length > 8 * 1024 * 1024) {
    throw new Error('ไฟล์สลิปมีขนาดใหญ่เกิน 6 MB');
  }

  const mime = String(image.mimeType || '').toLowerCase();
  if (['image/jpeg', 'image/png', 'image/webp'].indexOf(mime) < 0) {
    throw new Error('รองรับเฉพาะไฟล์ JPG, PNG หรือ WEBP');
  }

  const slipHash = sha256_(image.base64);
  const duplicate = rows_('Topups').find(function(r) {
    return r.slip_hash && String(r.slip_hash) === slipHash;
  });
  if (duplicate) {
    throw new Error('สลิปนี้ถูกส่งเข้าระบบแล้ว');
  }

  const folder =
    slipFolder_();

  const blob =
    Utilities.newBlob(
      Utilities.base64Decode(
        image.base64
      ),

      mime,

      'slip-' +
      newId_('') +
      '.jpg'
    );

  const file =
    folder.createFile(blob);

  file.setSharing(
    DriveApp.Access
      .ANYONE_WITH_LINK,
    DriveApp.Permission.VIEW
  );

  append_('Topups', {
    topup_id:
      newId_('TOP'),

    username:
      u.username,

    amount: amount,

    status:
      'รอแอดมินตรวจสอบ',

    slip_url:
      file.getUrl(),

    created_at:
      now_(),

    reviewed_at: '',
    note: '',
    slip_hash: slipHash
  });

  return {
    success: true,

    message:
      'ส่งสลิปเรียบร้อย รอแอดมินตรวจสอบและเติมเครดิต',

    newCredit:
      money_(u.credit),

    pending: true
  };
}

function slipFolder_() {
  if (
    CONFIG.SLIP_FOLDER_ID
  ) {
    return DriveApp.getFolderById(
      CONFIG.SLIP_FOLDER_ID
    );
  }

  const found =
    DriveApp.getFoldersByName(
      'Mailly OTP Slips'
    );

  return found.hasNext()
    ? found.next()
    : DriveApp.createFolder(
        'Mailly OTP Slips'
      );
}

function approveTopup(
  topupId,
  approve,
  note
) {
  return withScriptLock_(function() {
  const r = rows_('Topups').find(
    function(x) {
      return (
        String(x.topup_id) ===
        String(topupId)
      );
    }
  );

  if (!r) {
    throw new Error(
      'ไม่พบรายการเติมเงิน'
    );
  }

  if (
    String(r.status) !==
    'รอแอดมินตรวจสอบ'
  ) {
    throw new Error(
      'รายการนี้ถูกตรวจแล้ว'
    );
  }

  if (approve) {
    changeCredit_(
      r.username,
      Number(r.amount)
    );
  }

  updateRow_(
    'Topups',
    r._row,
    {
      status:
        approve
          ? 'อนุมัติแล้ว'
          : 'ปฏิเสธ',

      reviewed_at:
        now_(),

      note: note || ''
    }
  );

  return 'ดำเนินการเรียบร้อย';
  });
}

/* =====================================================
   PRODUCTS
===================================================== */

function buyProduct_(p) {
  const u = requireAuth_(p);

  if (
    p.username &&
    key_(p.username) !==
      key_(u.username)
  ) {
    throw new Error(
      'บัญชีผู้ซื้อไม่ตรงกับ Session'
    );
  }

  const product =
    rows_('Products').find(
      function(x) {
        return (
          String(
            x.product_id
          ) ===
            String(
              p.productId
            ) &&
          String(
            x.active
          ).toLowerCase() !==
            'false'
        );
      }
    );

  if (product) {
    const serverPrice = money_(product.price);
    if (serverPrice <= 0) {
      throw new Error('ราคาสินค้าในระบบไม่ถูกต้อง');
    }

    const stock =
      rows_('ProductStock').find(
        function(x) {
          return (
            String(
              x.product_id
            ) ===
              String(
                p.productId
              ) &&
            String(
              x.sold
            ).toLowerCase() !==
              'true'
          );
        }
      );

    if (!stock) {
      throw new Error(
        'สินค้าหมดสต็อก'
      );
    }

    if (
      money_(u.credit) <
      serverPrice
    ) {
      throw new Error(
        'เครดิตไม่เพียงพอ'
      );
    }

    const newCredit =
      changeCredit_(
        u.username,
        -serverPrice
      );

    updateRow_(
      'ProductStock',
      stock._row,
      {
        sold: true,
        sold_at: now_()
      }
    );

    const id =
      newId_('BUY');

    append_('Purchases', {
      purchase_id: id,
      username: u.username,
      product_id:
        product.product_id,
      product_name:
        product.name,
      price:
        serverPrice,
      item_data:
        stock.item_data,
      created_at: now_()
    });

    return {
      success: true,
      orderId: id,
      itemData:
        stock.item_data,
      newCredit: newCredit
    };
  }

  throw new Error('ไม่พบสินค้า หรือสินค้านี้ถูกปิดการขาย');
}

function getShopProducts_(p) {
  requireAuth_(p);
  const stocks = rows_('ProductStock');
  return {
    success: true,
    products: rows_('Products')
      .filter(function(x) {
        return String(x.active).toLowerCase() !== 'false';
      })
      .map(function(x) {
        return {
          id: x.product_id,
          name: x.name,
          description: x.description || '',
          category: x.category || 'other',
          price: money_(x.price),
          icon: x.icon || 'fa-box',
          logoUrl: x.logo_url || '',
          stock: stocks.filter(function(s) {
            return String(s.product_id) === String(x.product_id) &&
              String(s.sold).toLowerCase() !== 'true';
          }).length
        };
      })
  };
}

function getMyPurchases_(p) {
  const u = requireAuth_(p);
  return {
    success: true,
    purchases: rows_('Purchases')
      .filter(function(x) {
        return key_(x.username) === key_(u.username);
      })
      .slice(-50)
      .reverse()
      .map(function(x) {
        return {
          orderId: x.purchase_id,
          productId: x.product_id,
          productName: x.product_name,
          price: money_(x.price),
          itemData: x.item_data,
          createdAt: x.created_at
        };
      })
  };
}

function buyYtPackage_(p) {
  const u = requireAuth_(p);
  const packages = {
    pkg_individual: { name: 'YouTube รายบุคคล', price: 150 },
    pkg_monthly: { name: 'YouTube Family รายเดือน', price: 250 },
    pkg_transfer_india: { name: 'ย้ายแฟมไปอินเดีย', price: 375 },
    pkg_new_1year: { name: 'YouTube Family 1 ปี', price: 1440 }
  };
  const pkg = packages[String(p.packageId || '')];
  if (!pkg) {
    throw new Error('ไม่พบแพ็กเกจ YouTube ที่เลือก');
  }
  if (money_(u.credit) < pkg.price) {
    throw new Error('เครดิตไม่เพียงพอ');
  }
  const email = String(p.email || '').trim().toLowerCase();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error('รูปแบบ Email ไม่ถูกต้อง');
  }
  const id = newId_('YT');
  const newCredit = changeCredit_(u.username, -pkg.price);
  append_('Purchases', {
    purchase_id: id,
    username: u.username,
    product_id: String(p.packageId),
    product_name: pkg.name,
    price: pkg.price,
    item_data: email ? 'Email ลูกค้า: ' + email : 'ใช้อีเมลร้าน',
    created_at: now_()
  });
  append_('Inbox', {
    message_id: newId_('REQ'),
    username: CONFIG.ADMIN_USERNAME,
    message: 'คำสั่งซื้อ ' + id + ' จาก ' + u.username + ' | ' + pkg.name +
      (email ? ' | ' + email : ' | ใช้อีเมลร้าน'),
    created_at: now_()
  });
  return { success: true, orderId: id, newCredit: newCredit };
}

/* =====================================================
   YOUTUBE FAMILY / INBOX
===================================================== */

function getYtUserData_(p) {
  const u = requireAuth_(p);
  return {
    success: true,
    items: rows_('YTData')
    .filter(function(r) {
      return (
        key_(r.username) ===
        key_(u.username)
      );
    })
    .map(function(r) {
      return {
        username:
          r.username,

        familyId:
          r.family_id,

        email:
          r.email,

        status:
          r.status,

        expireDate:
          r.expire_date,

        slipUrl:
          r.slip_url
      };
    })
  };
}

function getAllYtDataForAdmin_(p) {
  requireAdmin_(p);
  return {
    success: true,
    items: rows_('YTData').map(
    function(r) {
      return {
        rowNumber: r._row,
        username:
          r.username,
        familyId:
          r.family_id,
        email:
          r.email,
        status:
          r.status,
        expireDate:
          r.expire_date,
        slipUrl:
          r.slip_url
      };
    }
    )
  };
}

function updateYtUserDataFromAdmin_(p) {
  requireAdmin_(p);
  const rowNumber = Number(p.rowNumber);
  const sh = sheet_('YTData');
  if (!Number.isInteger(rowNumber) || rowNumber < 2 || rowNumber > sh.getLastRow()) {
    throw new Error(
      'rowNumber ไม่ถูกต้อง'
    );
  }

  updateRow_(
    'YTData',
    rowNumber,
    {
      status:
        p.newStatus || '',

      expire_date:
        p.newExpireDate || '',

      updated_at:
        now_()
    }
  );

  return { success: true };
}

function processYtPayment_(p) {
  requireAuth_(p);
  throw new Error('ฟังก์ชันชำระ YouTube ด้วยสลิปถูกยกเลิก กรุณาชำระด้วยเครดิตในบัญชี');
}

function getInbox_(p) {
  const u = requireAuth_(p);
  return {
    messages:
      rows_('Inbox')
        .filter(function(r) {
          return (
            key_(r.username) ===
            key_(u.username)
          );
        })
        .map(function(r) {
          return {
            message:
              r.message,

            date:
              r.created_at
          };
        })
  };
}

function sendInbox_(p) {
  requireAdmin_(p);
  user_(
    p.username,
    false
  );

  append_('Inbox', {
    message_id:
      newId_('MSG'),

    username:
      p.username,

    message:
      String(
        p.message || ''
      ).slice(0, 2000),

    created_at:
      now_()
  });

  return {
    success: true
  };
}

function requestBackupEmail_(p) {
  const u = requireAuth_(p);
  append_('Inbox', {
    message_id:
      newId_('REQ'),

    username:
      CONFIG.ADMIN_USERNAME,

    message:
      'คำขอเมลสำรองจาก ' +
      u.username +
      ' | email: ' +
      p.email +
      ' | family: ' +
      p.familyId,

    created_at:
      now_()
  });

  return {
    success: true
  };
}
